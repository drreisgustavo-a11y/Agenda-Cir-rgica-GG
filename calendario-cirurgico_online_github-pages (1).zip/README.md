# Calendário Cirúrgico (Publicação rápida)

Este pacote contém um `index.html` pronto para ser publicado online para acesso em outros dispositivos.

## Opção A — GitHub Pages (gratuito e público)
1. Crie um repositório público no GitHub (ex.: `calendario-cirurgico`).
2. Faça **upload** do arquivo `index.html` para a **raiz** do repositório.
3. Vá em **Settings → Pages**.
4. Em *Build and deployment*, selecione **Deploy from a branch**.
5. Branch: `main` · Folder: `/ (root)` · Salve.
6. A página ficará disponível em: `https://SEU_USUARIO.github.io/calendario-cirurgico`.

## Opção B — Netlify Drop (arraste‑e‑solte)
1. Acesse o Netlify Drop (busque por "Netlify Drop" no Google).
2. Arraste o arquivo `index.html` para a página.
3. O Netlify gera um link público instantaneamente.

## Observação importante
Este HTML salva os dados no **navegador local** (localStorage). Isso **não sincroniza** entre dispositivos. Para compartilhar dados entre computadores, exporte **CSV** e importe no outro dispositivo.
